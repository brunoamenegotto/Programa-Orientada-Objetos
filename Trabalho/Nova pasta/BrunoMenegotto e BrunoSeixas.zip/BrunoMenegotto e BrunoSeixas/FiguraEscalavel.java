public interface FiguraEscalavel 
{
    public void aumentarObjeto(int a);
    public void diminuirObjeto(int b);
}